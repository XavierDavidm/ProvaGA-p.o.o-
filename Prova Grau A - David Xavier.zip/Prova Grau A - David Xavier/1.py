class Jogador:
    def __init__(self):   #atributos->nome,posicao,dataNascimento,nacionalidade,altura,peso
        #os atributos serão substituidos nos sets
        self.__nome=0
        self.__posicao=0
        self.__dataNascimento=0
        self.__nacionalidade=0
        self.__altura=0
        self.__peso=0
        
    #---GETTERS E SETTERS DOS ATRIBUTOS---
    
    #nome
    @property
    def nome(self):
        return self.__nome
    @nome.setter
    def nome(self):
        raise ValueError('erro nome')
    def registarNome(self):
        nome=str(input('digite o nome completo do jogador: '))
        self.__nome=nome
    def getNome(self):
        return self.__nome
    #posicao
    @property
    def posicao(self):
        return self.__posicao
    @posicao.setter
    def posicao(self):
        raise ValueError('erro posição')
    def registarPosicao(self):
        posicao=str(input('digite a posição do jogador(defesa/meio-campo/atacante): '))
        self.__posicao=posicao
    def getPosicao(self):
        return self.__posicao
    #dataNascimento
    @property
    def dataNascimento(self):
        return self.__dataNascimento
    @dataNascimento.setter
    def dataNascimento(self):
        raise ValueError('erro dataNascimento')
    def registarDataNascimento(self):
        dataNascimento=int(input('digite a data de Nascimento do jogador(ANO): '))
        self.__dataNascimento=dataNascimento
    def getDataNascimento(self):
        return self.__dataNascimento
    #nacionalidade
    @property
    def nacionalidade(self):
        return self.__nacionalidade
    @nacionalidade.setter
    def nacionalidade(self):
        raise ValueError('erro nacionalidade')
    def registarNacionalidade(self):
        nacionalidade=str(input('digite a nacionalidade do jogador: '))
        self.__nacionalidade=nacionalidade
    def getNacionalidade(self):
        return self.__nacionalidade
    #altura
    @property
    def altura(self):
        return self.__altura
    @altura.setter
    def altura(self):
        raise ValueError('erro altura')
    def registarAltura(self):
        altura=float(input('digite a altura do jogador: '))
        self.__altura=altura
    def getAltura(self):
        return self.__altura
    #peso
    @property
    def peso(self):
        return self.__peso
    @peso.setter
    def peso(self):
        raise ValueError('erro peso')
    def registarPeso(self):
        peso=float(input('digite o peso do jogador: '))
        self.__peso=peso
    def getPeso(self):
        return self.__peso
    #gerador de jogador(chama todos os sets)
    def gerarJogador(self):
        self.registarNome()
        self.registarPosicao()
        self.registarDataNascimento()
        self.registarNacionalidade()
        self.registarAltura()
        self.registarPeso()
        
    #---METODOS---
    #imprime todos os dados do jogador(permite o usuario cadastrar um jogador)
    def imprimirDados(self):
        print('')
        print('Dados Do Jogador')
        print('Nome:',self.getNome())
        print('Posição:',self.getPosicao())
        print('Data de Nascimento:',self.getDataNascimento())
        print('Nacionalidade:',self.getNacionalidade())
        print('Altura:',self.getAltura())
        print('Peso:',self.getPeso())
        print('')
        
    #calcula a idade do jogador com base na data de nascimento(não inclui dia e mes, so calcula apartir do ano)
    def calcularIdade(self):
        idade=2024-(self.getDataNascimento())
        return idade
             
    #mostra quanto tempo falta para o jogador se aposentar conforme sua posição no time
    def calcularAposentadoria(self):
        if self.getPosicao()=='defesa':
            tempoRestante=40-int(self.calcularIdade())
            print('o jogador',self.getNome(),'tem',self.calcularIdade(),'Anos')
            print('faltam em media',tempoRestante,'anos para o jogador',self.getNome(),'se aposentar como',self.getPosicao())
        elif self.getPosicao()=='meio-campo':
            tempoRestante=38-int(self.calcularIdade())
            print('o jogador',self.getNome(),'tem',self.calcularIdade(),'Anos')
            print('faltam em media',tempoRestante,'anos para o jogador',self.getNome(),'se aposentar como',self.getPosicao())
        elif self.getPosicao()=='atacante':
            tempoRestante=35-int(self.calcularIdade())
            print('o jogador',self.getNome(),'tem',self.calcularIdade(),'Anos')
            print('faltam em media',tempoRestante,'anos para o jogador',self.getNome(),'se aposentar como',self.getPosicao())
        else:
            print('ERRO')
            
#main/teste 
#sempre usar o gerarJogador para chamar todos os sets durante testes
jogador1=Jogador()
jogador1.gerarJogador()
jogador1.imprimirDados()
jogador1.calcularIdade()
jogador1.calcularAposentadoria()






