class Data: #data(DD/MM/AAAA)
    def __init__(self,data):
        dataStr=str(data)
        if len(dataStr)==10: #verifica se o modelo da data está correto
            self.__data=dataStr
        else:
            self.__data='01/01/0001'
     
    #getters   
    def getDataStr(self):
        return self.__data
    
    def getDia(self):
        dia=(self.__data).split('/')
        return int(dia[0])
    
    def getMes(self):
        mes=(self.__data).split('/')
        return int(mes[1])
    
    def getMesExtenso(self):
        mes=(self.__data).split('/')
        r=int(mes[1])-1
        meses=('janeiro','fevereiro','março','abril','maio','junho','julho','agosto','setembro','outubro','novembro','dezembro')
        return meses[r]
        
    def getAno(self):
        ano=(self.__data).split('/')
        return int(ano[2])
    
    def isBissexto(self):
        ano = (self.__data).split('/')
        ano=int(ano[2])
        if (ano % 4 == 0 and ano % 100 != 0) or ano % 400 == 0: 
            return True
        else: 
            return False
        
    #metodo comparação
    def compara(self,data2):
        #comparador de igualdade total
        if self.__data==data2.getDataStr():
            return '0'
        #comparador de anos
        elif self.getAno() > data2.getAno():
            return '1'
        elif self.getAno() < data2.getAno():
            return '-1'
        #comparador de mes em anos iguais
        elif self.getAno() == data2.getAno():
            if self.getMes() > data2.getMes():
                return '1'
            elif self.getMes() < data2.getMes():
                return '-1'
            #comparador de dias em meses iguais
            elif self.getMes() == data2.getMes():
                if self.getDia() > data2.getDia():
                    return '1'
                elif self.getDia() < data2.getDia():
                    return '-1'
                
                
#menu/teste 
data1=Data('20/09/2024') #corrente
data2=Data('01/10/2010') #parametro

#teste retornos data 1
print(data1.getDia())
print(data1.getMes())
print(data1.getAno())
print(data1.getMesExtenso())
print(data1.isBissexto())

#teste comparação data1 e data2
print(data1.compara(data2))